SyncService — portable build
--------------------------------
Double-click SyncService.exe to start the service.

This folder also contains:
- config.json
- .env
- django_sync/ (your Django package, templates, static, etc.)
Edit config.json or .env as needed; no rebuild required.
